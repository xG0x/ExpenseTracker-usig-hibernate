package app;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.time.LocalDate;

public class FinanceApp {
    public static void main(String[] args){
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        User u = new User();
        u.setName("Leo");
        u.setEmail("leo@gmail.com");
        u.setPassword("1234");
        session.save(u);

        Category c = new Category();
        c.setName("Food");
        session.save(c);

        Budget b = new Budget();
        b.setUser(u);
        b.setCategory(c);
        b.setMonth(LocalDate.now().getMonthValue());
        b.setYear(LocalDate.now().getYear());
        b.setLimitAmount(5000);
        session.save(b);

        tx.commit();
        session.close();
        System.out.println("DONE!");
        HibernateUtil.getSessionFactory().close();
    }
}
