package app;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
public class Transaction {

    public enum Type { INCOME, EXPENSE }

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private double amount;
    private LocalDate date;

    @Enumerated(EnumType.STRING)
    private Type type;

    private String description;

    @ManyToOne
    private User user;

    @ManyToOne
    private Category category;

    public Transaction(){}

    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public double getAmount(){return amount;}
    public void setAmount(double amount){this.amount=amount;}
    public LocalDate getDate(){return date;}
    public void setDate(LocalDate date){this.date=date;}
    public Type getType(){return type;}
    public void setType(Type type){this.type=type;}
    public String getDescription(){return description;}
    public void setDescription(String description){this.description=description;}
    public User getUser(){return user;}
    public void setUser(User user){this.user=user;}
    public Category getCategory(){return category;}
    public void setCategory(Category category){this.category=category;}
}
