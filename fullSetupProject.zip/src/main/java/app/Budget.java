package app;

import javax.persistence.*;

@Entity
public class Budget {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int month;
    private int year;
    private double limitAmount;

    @ManyToOne
    private User user;

    @ManyToOne
    private Category category;

    public Budget(){}

    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public int getMonth(){return month;}
    public void setMonth(int month){this.month=month;}
    public int getYear(){return year;}
    public void setYear(int year){this.year=year;}
    public double getLimitAmount(){return limitAmount;}
    public void setLimitAmount(double limitAmount){this.limitAmount=limitAmount;}
    public User getUser(){return user;}
    public void setUser(User user){this.user=user;}
    public Category getCategory(){return category;}
    public void setCategory(Category category){this.category=category;}
}
